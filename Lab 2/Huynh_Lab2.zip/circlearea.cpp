// This program will output the circumference and area
// of the circle with a given radius.

// Hue Anh Huynh
// 1/23/17

/*
Exercise 3: After changing the data type of circumference from float to int, I got:
The circumference of the circle is 33 units
The area of the circle is 91.5624 units^2

The circumference changed to 33 units because the variable type came an integer which is a data type that doesn't support decimals
*/

#include <iostream>
using namespace std;

const double pi = 3.14;
const double rad = 5.4;
int main()
{
	double area;
	float circumference;
	circumference = 2 * pi * rad;
	area = pi * (rad * rad);

	cout << "The circumference of the circle is " << circumference << " units" << endl;
    cout << "The area of the circle is " << area << " units^2" << endl;

	return 0;
}
